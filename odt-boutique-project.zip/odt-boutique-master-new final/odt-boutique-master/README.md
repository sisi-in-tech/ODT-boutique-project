#mongoDB 

src\server\dist ，由vue project, npm run build (package) ，new dist document instead 

#commend
npm run dev
# mongoose npm i mongoose@5.7.0 
 "mongoose": "^5.13.14",

